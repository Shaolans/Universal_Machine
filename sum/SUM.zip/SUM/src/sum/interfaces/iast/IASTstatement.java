package sum.interfaces.iast;

public interface IASTstatement extends IAST {

}
