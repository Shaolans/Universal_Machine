package sum.interfaces.iast;

public interface IAST extends IASTvisitable {

}
