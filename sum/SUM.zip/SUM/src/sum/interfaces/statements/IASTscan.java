package sum.interfaces.statements;

import sum.interfaces.iast.IASTstatement;

public interface IASTscan extends IASTstatement{
	public String getName();
}
