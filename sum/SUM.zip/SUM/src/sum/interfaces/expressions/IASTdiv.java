package sum.interfaces.expressions;

public interface IASTdiv extends IASTbinOp {

}
