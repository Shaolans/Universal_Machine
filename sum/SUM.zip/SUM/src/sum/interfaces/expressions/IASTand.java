package sum.interfaces.expressions;

public interface IASTand extends IASTbinOp {

}
