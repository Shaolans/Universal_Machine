package sum.interfaces.expressions;

public interface IASTnot extends IASTunaryOp {

}
