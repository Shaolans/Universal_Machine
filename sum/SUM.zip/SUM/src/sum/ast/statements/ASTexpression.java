package sum.ast.statements;

import sum.ast.ast.ASTstatement;

public abstract class ASTexpression extends ASTstatement {

}
