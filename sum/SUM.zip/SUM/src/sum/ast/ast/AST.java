package sum.ast.ast;

import sum.interfaces.iast.IAST;

public abstract class AST implements IAST {



}
