package sum.interfaces.iast;

public interface IASTexpression extends IASTstatement {

}
