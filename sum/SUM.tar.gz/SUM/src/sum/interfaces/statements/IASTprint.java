package sum.interfaces.statements;

import sum.interfaces.iast.IASTstatement;

public interface IASTprint extends IASTstatement{
	public IASTstatement getArg();
}
