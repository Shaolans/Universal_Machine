package sum.interfaces.expressions;

public interface IASTeq extends IASTbinOp {

}
