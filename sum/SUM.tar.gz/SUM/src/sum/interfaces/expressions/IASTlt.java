package sum.interfaces.expressions;

public interface IASTlt extends IASTbinOp {

}
