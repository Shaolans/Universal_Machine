package sum.interfaces.expressions;

public interface IASTadd extends IASTbinOp {

}
