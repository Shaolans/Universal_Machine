package sum.interfaces.expressions;

public interface IASTor extends IASTbinOp {

}
