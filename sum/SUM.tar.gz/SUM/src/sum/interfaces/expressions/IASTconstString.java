package sum.interfaces.expressions;

import sum.interfaces.iast.IASTexpression;

public interface IASTconstString extends IASTexpression {
	public String getString();
}
