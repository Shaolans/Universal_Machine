package sum.interfaces.expressions;

public interface IASTmul extends IASTbinOp {

}
