package sum.interfaces.expressions;

import sum.interfaces.iast.IASTexpression;

public interface IASTconstInteger extends IASTexpression {
	public int getInteger();
}
