package sum.interfaces.expressions;

public interface IASTgt extends IASTbinOp {

}
