package sum.ast.ast;


public abstract class ASTstatement extends AST {


}
